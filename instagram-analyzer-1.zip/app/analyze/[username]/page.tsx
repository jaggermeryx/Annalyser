"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Shield, Search, FileText, AlertTriangle, CheckCircle } from "lucide-react"

const analysisSteps = [
  { id: 1, label: "Fetching account data", icon: Search, duration: 2000 },
  { id: 2, label: "Analyzing post content", icon: FileText, duration: 3000 },
  { id: 3, label: "Checking guideline violations", icon: AlertTriangle, duration: 2500 },
  { id: 4, label: "Generating report", icon: Shield, duration: 1500 },
]

export default function AnalyzePage() {
  const params = useParams()
  const router = useRouter()
  const username = params.username as string
  const [currentStep, setCurrentStep] = useState(0)
  const [progress, setProgress] = useState(0)
  const [stepProgress, setStepProgress] = useState(0)

  useEffect(() => {
    if (!username) {
      router.push("/")
      return
    }

    const totalDuration = 0
    let currentDuration = 0

    const runAnalysis = async () => {
      for (let i = 0; i < analysisSteps.length; i++) {
        setCurrentStep(i)
        setStepProgress(0)

        const step = analysisSteps[i]
        const stepStart = Date.now()

        // Animate step progress
        const stepInterval = setInterval(() => {
          const elapsed = Date.now() - stepStart
          const stepProg = Math.min((elapsed / step.duration) * 100, 100)
          setStepProgress(stepProg)

          // Update overall progress
          const overallProg =
            ((currentDuration + elapsed) / analysisSteps.reduce((acc, s) => acc + s.duration, 0)) * 100
          setProgress(Math.min(overallProg, 100))
        }, 50)

        // Wait for step to complete
        await new Promise((resolve) => setTimeout(resolve, step.duration))
        clearInterval(stepInterval)

        currentDuration += step.duration
        setStepProgress(100)
      }

      // Analysis complete, navigate to results
      setTimeout(() => {
        router.push(`/results/${encodeURIComponent(username)}`)
      }, 500)
    }

    runAnalysis()
  }, [username, router])

  if (!username) return null

  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <div className="p-4 rounded-full bg-primary/10 animate-pulse">
                <Shield className="w-12 h-12 text-primary" />
              </div>
            </div>
            <h1 className="text-3xl font-bold mb-4">Analyzing Account</h1>
            <p className="text-xl text-muted-foreground">
              Analyzing <span className="text-primary font-semibold">@{decodeURIComponent(username)}</span> for
              guideline violations
            </p>
          </div>

          {/* Progress Card */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="space-y-6">
                {/* Overall Progress */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Overall Progress</span>
                    <span className="font-medium">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                {/* Current Step */}
                <div className="space-y-4">
                  {analysisSteps.map((step, index) => {
                    const StepIcon = step.icon
                    const isActive = index === currentStep
                    const isCompleted = index < currentStep
                    const isUpcoming = index > currentStep

                    return (
                      <div
                        key={step.id}
                        className={`flex items-center space-x-4 p-4 rounded-lg transition-all ${
                          isActive
                            ? "bg-primary/10 border border-primary/20"
                            : isCompleted
                              ? "bg-secondary/10"
                              : "bg-muted/20"
                        }`}
                      >
                        <div
                          className={`p-2 rounded-full ${
                            isActive
                              ? "bg-primary text-primary-foreground animate-pulse"
                              : isCompleted
                                ? "bg-secondary text-secondary-foreground"
                                : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {isCompleted ? <CheckCircle className="w-5 h-5" /> : <StepIcon className="w-5 h-5" />}
                        </div>

                        <div className="flex-1">
                          <p
                            className={`font-medium ${
                              isActive ? "text-primary" : isCompleted ? "text-secondary" : "text-muted-foreground"
                            }`}
                          >
                            {step.label}
                          </p>

                          {isActive && (
                            <div className="mt-2">
                              <Progress value={stepProgress} className="h-1" />
                            </div>
                          )}
                        </div>

                        {isCompleted && <CheckCircle className="w-5 h-5 text-secondary" />}
                      </div>
                    )
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Info */}
          <div className="text-center text-sm text-muted-foreground">
            <p>This process typically takes 30-60 seconds depending on account size and content volume.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
