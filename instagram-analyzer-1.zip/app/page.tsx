"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, AlertTriangle, Eye } from "lucide-react"

export default function HomePage() {
  const [username, setUsername] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim()) return

    setIsLoading(true)
    // Navigate to analysis page with username
    router.push(`/analyze/${encodeURIComponent(username.trim())}`)
  }

  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="p-4 rounded-full bg-primary/10">
                <Shield className="w-12 h-12 text-primary" />
              </div>
            </div>
            <h1 className="text-4xl font-bold text-balance">Instagram Guideline Analyzer</h1>
            <p className="text-xl text-muted-foreground text-pretty">
              Analyze Instagram accounts for potential guideline violations including hate speech, violence, self-harm
              content, and other policy breaches.
            </p>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-4 my-12">
            <Card className="bg-card/50">
              <CardContent className="p-6 text-center">
                <AlertTriangle className="w-8 h-8 text-destructive mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Content Analysis</h3>
                <p className="text-sm text-muted-foreground">Detects hate speech, violence, and harmful content</p>
              </CardContent>
            </Card>
            <Card className="bg-card/50">
              <CardContent className="p-6 text-center">
                <Eye className="w-8 h-8 text-accent mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Privacy Focused</h3>
                <p className="text-sm text-muted-foreground">No follower counts or personal metrics displayed</p>
              </CardContent>
            </Card>
            <Card className="bg-card/50">
              <CardContent className="p-6 text-center">
                <Shield className="w-8 h-8 text-secondary mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Guideline Check</h3>
                <p className="text-sm text-muted-foreground">Comprehensive policy violation detection</p>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Form */}
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle>Start Analysis</CardTitle>
              <CardDescription>Enter an Instagram username to analyze for guideline violations</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAnalyze} className="space-y-4">
                <div className="space-y-2">
                  <Input
                    type="text"
                    placeholder="Enter Instagram username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="text-center"
                    disabled={isLoading}
                  />
                  <p className="text-xs text-muted-foreground">Username only (without @ symbol)</p>
                </div>
                <Button type="submit" className="w-full" disabled={!username.trim() || isLoading}>
                  {isLoading ? "Starting Analysis..." : "Analyze Account"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Disclaimer */}
          <div className="text-center text-sm text-muted-foreground max-w-lg mx-auto">
            <p>
              This tool analyzes publicly available content for educational purposes. Results are estimates and should
              not be considered definitive policy violations.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
