// Instagram Guideline Analysis Service
// This simulates the analysis logic that would typically connect to ML models or content analysis APIs

export interface GuidelineViolation {
  category: string
  severity: "Low" | "Medium" | "High"
  description: string
  examples: string[]
  confidence: number
}

export interface GuidelineWarning {
  category: string
  severity: "Low" | "Medium" | "High"
  description: string
  examples: string[]
  confidence: number
}

export interface PassedGuideline {
  category: string
  description: string
}

export interface AnalysisResult {
  violations: GuidelineViolation[]
  warnings: GuidelineWarning[]
  passed: PassedGuideline[]
  analysisDate: Date
  accountUsername: string
}

// Comprehensive list of Instagram community guidelines
const GUIDELINE_CATEGORIES = {
  HATE_SPEECH: {
    name: "Hate Speech",
    description: "Content that attacks people based on protected characteristics",
    keywords: ["hate", "toxic", "racist", "discrimination", "slur"],
  },
  VIOLENCE: {
    name: "Violence & Incitement",
    description: "Content that promotes, encourages, or depicts violence",
    keywords: ["violence", "fight", "attack", "threat", "harm"],
  },
  SELF_HARM: {
    name: "Self-Harm Content",
    description: "Content promoting self-injury, suicide, or eating disorders",
    keywords: ["suicide", "selfharm", "cutting", "anorexia", "bulimia"],
  },
  HARASSMENT: {
    name: "Bullying & Harassment",
    description: "Content that harasses, intimidates, or bullies individuals",
    keywords: ["bully", "harass", "stalk", "intimidate", "doxx"],
  },
  SPAM: {
    name: "Spam & Inauthentic Behavior",
    description: "Automated behavior, fake engagement, or repetitive content",
    keywords: ["spam", "bot", "fake", "scam", "phishing"],
  },
  MISINFORMATION: {
    name: "Misinformation",
    description: "False information that could cause harm",
    keywords: ["conspiracy", "hoax", "fake news", "medical misinformation"],
  },
  ADULT_CONTENT: {
    name: "Adult Content",
    description: "Sexually explicit or suggestive content",
    keywords: ["nsfw", "explicit", "sexual", "nude"],
  },
  COPYRIGHT: {
    name: "Intellectual Property",
    description: "Unauthorized use of copyrighted material",
    keywords: ["copyright", "piracy", "stolen", "unauthorized"],
  },
  PRIVACY: {
    name: "Privacy Violations",
    description: "Sharing private information without consent",
    keywords: ["doxxing", "private info", "leak", "personal data"],
  },
  DANGEROUS_ORGS: {
    name: "Dangerous Organizations",
    description: "Content supporting terrorist or criminal organizations",
    keywords: ["terrorist", "extremist", "criminal organization"],
  },
}

// Simulate content analysis based on username patterns
export function analyzeAccount(username: string): AnalysisResult {
  const violations: GuidelineViolation[] = []
  const warnings: GuidelineWarning[] = []
  const passed: PassedGuideline[] = []

  const lowerUsername = username.toLowerCase()

  // Check for potential violations based on username patterns
  Object.entries(GUIDELINE_CATEGORIES).forEach(([key, category]) => {
    const hasKeywords = category.keywords.some((keyword) => lowerUsername.includes(keyword))

    if (hasKeywords) {
      // High confidence violation
      violations.push({
        category: category.name,
        severity: "High",
        description: category.description,
        examples: generateExamples(category.name),
        confidence: 0.85 + Math.random() * 0.1,
      })
    } else if (Math.random() > 0.7) {
      // Random warnings for demonstration
      warnings.push({
        category: category.name,
        severity: ["Low", "Medium"][Math.floor(Math.random() * 2)] as "Low" | "Medium",
        description: `Potential ${category.description.toLowerCase()} detected`,
        examples: generateExamples(category.name, true),
        confidence: 0.4 + Math.random() * 0.3,
      })
    } else {
      // Passed guidelines
      passed.push({
        category: category.name,
        description: `No ${category.description.toLowerCase()} detected`,
      })
    }
  })

  // Ensure we always have some passed guidelines
  if (passed.length === 0) {
    passed.push(
      {
        category: "Self-Harm Content",
        description: "No self-harm or suicide-related content detected",
      },
      {
        category: "Adult Content",
        description: "No inappropriate adult content found",
      },
    )
  }

  return {
    violations,
    warnings,
    passed,
    analysisDate: new Date(),
    accountUsername: username,
  }
}

function generateExamples(category: string, isWarning = false): string[] {
  const examples: Record<string, string[]> = {
    "Hate Speech": [
      "Posts containing discriminatory language",
      "Comments targeting specific communities",
      "Use of derogatory terms or slurs",
    ],
    "Violence & Incitement": [
      "Posts encouraging physical confrontation",
      "Sharing violent imagery or videos",
      "Threats against individuals or groups",
    ],
    "Self-Harm Content": [
      "Posts promoting self-injury methods",
      "Content glorifying eating disorders",
      "Suicide-related imagery or instructions",
    ],
    "Bullying & Harassment": [
      "Targeted harassment campaigns",
      "Sharing private information to shame",
      "Coordinated attacks on individuals",
    ],
    "Spam & Inauthentic Behavior": [
      "Repetitive posting patterns",
      "Mass following/unfollowing behavior",
      "Automated engagement activities",
    ],
    Misinformation: [
      "Health claims without scientific backing",
      "Unverified news or conspiracy theories",
      "Manipulated media presented as fact",
    ],
    "Adult Content": [
      "Sexually explicit imagery",
      "Inappropriate content involving minors",
      "Adult services promotion",
    ],
    "Intellectual Property": [
      "Unauthorized use of copyrighted music",
      "Sharing pirated content",
      "Using trademarked material without permission",
    ],
    "Privacy Violations": [
      "Sharing personal information without consent",
      "Posting private conversations",
      "Location tracking without permission",
    ],
    "Dangerous Organizations": [
      "Content supporting extremist groups",
      "Recruitment materials for criminal organizations",
      "Terrorist propaganda or symbols",
    ],
  }

  const categoryExamples = examples[category] || ["Potential policy violation detected"]

  if (isWarning) {
    return categoryExamples.map((example) => `Possible ${example.toLowerCase()}`)
  }

  return categoryExamples.slice(0, 2 + Math.floor(Math.random() * 2))
}

// Simulate analysis delay for realistic UX
export async function performAnalysis(username: string): Promise<AnalysisResult> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000 + Math.random() * 2000))

  return analyzeAccount(username)
}
